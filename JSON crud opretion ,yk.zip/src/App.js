 /*{json-server -P 3006 -w db.json}*/
 /*{react-scripts start}*/
 /*
 First start the json server thruogh package.json in file 
 in start portal put this code
 {json-server -P 3006 -w db.json}
then start npm terminal 
then same in json start portal put link code this
{react-scripts start}
then start npm 
all project is start 
ok
 */


import './App.css';
import HomePageApp from './CrudOperation1MyServer/HomePageApp';
// import Appeg1 from "./JsonServereg/components/Appeg1"


function App() {

return (
    <div className="App">
      <HomePageApp/>
    </div>
  );
}

export default App;
