import React, { Component } from 'react'
import { API_URL, createRecord } from './constant'
import axios from 'axios';
import './crud1.css'

export default class CreateData extends Component {
 state = {
  ...createRecord
 }

 componentDidMount() {
  console.log(this.props.selected && Object.keys(this.props.selected)?.length, 'isEdit', this.props.isEdit);
 }

 componentDidUpdate(prevProps, prevState) {
  console.log(this.props.selected && Object.keys(this.props.selected)?.length, 'isEdit', this.props.isEdit);

  if (this.props.selected !== undefined && this.props.selected !== prevProps.selected) {
   this.setState({
    ...this.props.selected
   });
  }
 }

 resetState = () => {
  this.setState({
   ...createRecord
  });
  this.props.handleSelected()
 }

 createData = () => {
  console.log(this.state);
  const newRecord = { ...this.state }
  axios({
   method: this.props.selected && Object.keys(this.props.selected)?.length ? 'put' : 'post',
   url: this.props.selected && Object.keys(this.props.selected)?.length ? `${API_URL}/${newRecord.id}` : API_URL,
   data: JSON.stringify(newRecord)
  }).then(res => {
   console.log(res);
   this.resetState();
  }).catch(err => {
   console.log('error', err);
  })
 }

 handleChange = (e) => {
  const { name, value } = e.target;
  this.setState({
   [name]: value
  });
 }

 deleteData = () => {
  console.log(this.state);
  const newRecord = { ...this.state }
  axios({
   method: 'delete',
   url: `${API_URL}/${newRecord.id}`
  }).then(res => {
   console.log(res);
   this.resetState();
  }).catch(err => {
   console.log('error', err);
  })
 }

 render() {
  return (
   <div>
    {this.props.selected && Object.keys(this.props.selected)?.length ? 'Edit Data' : 'CreateData'}
   
    <span className='inputbox' >
 
    <div className="form-floating mb-3 mt-3" id='inputbox1' >
    <input  
    type="text" 
    className="form-control " 
    value={this.state.id}
      onChange={this.handleChange}
      name="id"
      placeholder='Enter the id'
     />
    <label >Enter the id</label>
  </div>
   
    <div className="form-floating mb-3 mt-3 "  id='inputbox2' >
    <input  
    type="text" 
    className="form-control " 
    value={this.state.name}
      onChange={this.handleChange}
      name='name'
      placeholder='Enter the name'
     />
    <label >Enter the name</label>
  </div>
   
    <div className="form-floating mb-3 mt-3 "  id='inputbox3' >
    <input  
    type="text" 
    className="form-control " 
    value={this.state.email}
      onChange={this.handleChange}
      name='email'
      placeholder='Enter the email'
     />
    <label >Enter the email</label>
  </div>
   
    <div className="form-floating mb-3 mt-3 "  id='inputbox4' >
    <input  
    type="text" 
    className="form-control " 
    value={this.state.city}
      onChange={this.handleChange}
      name='city'
      placeholder='Enter the city'
     />
    <label >Enter the city</label>
  </div>
  </span>

    <div style={{ marginTop: '10px' }}>
     <span>

      <button onClick={this.createData}>Submit</button>
     </span>

     {this.props.selected && Object.keys(this.props.selected)?.length ?
      <span> <button onClick={this.deleteData}>Delete</button></span>
      :
      null
     }

    </div>
   </div>
  )
 }
}
/*
<div className="form-floating mb-3 mt-3 "  id='inputbox3' style={{
        width:400,marginLeft:570
    }} >
    <input  
    type="text" 
    className="form-control " 
    value={this.state.text}
      onChange={this.handleChange}
      
      placeholder='Enter the to do'
     />
    <label >Enter the to do </label>
  </div>
  */