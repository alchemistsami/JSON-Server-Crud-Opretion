// start server 
//   json-server --watch db.json --port 3001

export const API_URL = "http://localhost:3000/contacts";



export const createRecord = {
    id:"",
    name:"",
    email:"",
    city:""
}