import React, { Component } from 'react'
import axios from 'axios';
import './crud1.css'


import { API_URL } from './constant';

export default class GetData extends Component {
  state = {
    contacts: []
  }

  // setData = (__data) => {
  //  this.setState({ products: __data })
  // }

  componentDidMount() {
    console.log('inside componentDidMount');
    this.getData();
  }

  getData = () => {
    axios.get(API_URL)
      .then((response) => {
        // handle success
        // this.setData(response.data);
        this.setState({ contacts: response.data.slice(0,8) })
      })
      .catch(function (error) {
        // handle error
        console.log(error);
      });
  }

  render() {
    return (
      <div>
      
        {/* <button onClick={this.getData}>Fetch records from API</button> */}

        <div class="card">
        <div class="card-header" id='collapse1' >
          <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
          Show All API Data 
          </a>
        </div>
        <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
          <div class="card-body">
          <div>
          <ul>
            {this.state.contacts?.map((product) => (
              <li key={product.id} style={{
                fontSize:'16px' ,textDecorationStyle:'none'
              }} 
              onClick={()=>this.props.handleSelected(product)}>
                {product.id}) {product.name}  &  {product.city}.
              </li>
            )
            )}
          </ul>
        </div>
          </div>
        </div>
      </div>


        


      </div>
    )
  }
}
