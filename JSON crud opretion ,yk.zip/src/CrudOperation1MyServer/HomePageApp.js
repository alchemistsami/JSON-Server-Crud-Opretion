import React from 'react';
// import './App.css';
import CreateData from './CreateData';
import GetData from './GetData';

class HomePageApp extends React.Component {
  state = {
    selected: {},
    isEdit: false
  }
  handleSelected = (value) => {
    // console.log(!!value);
    this.setState({ selected: { ...value }, isEdit: !!value })
  }
  render() {

    return (
      <div >
        <GetData handleSelected={this.handleSelected} />
        {console.log(!this.state.selected)}
        <CreateData isEdit={true} selected={this.state.selected} handleSelected={this.handleSelected} />
        {/* {Object.keys(this.state.selected).length <= 0 ? <CreateData />
        :<CreateData isEdit={true} selected={this.state.selected} handleSelected={this.handleSelected} />} */}
      </div>
    );
  }
}

export default HomePageApp;
